import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import tkinter.font as tkfont
import random
import string
import os
import sys
import re
import requests

LUA_KEYWORDS = [
    "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
    "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
    "true", "until", "while"
]

KEY_FILE = "key.txt"


def generate_key():
    part = lambda: ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
    key = f"{part()}_{random.choice(string.ascii_uppercase)}{random.choice(string.ascii_uppercase)}#{random.randint(10, 99)}_{part()}"
    with open(KEY_FILE, 'w') as f:
        f.write(key)
    print(f"Key: {key}")


def delete_key_file():
    if os.path.exists(KEY_FILE):
        os.remove(KEY_FILE)


def read_key_file():
    if not os.path.exists(KEY_FILE):
        return None
    with open(KEY_FILE, 'r') as f:
        return f.read().strip()


if len(sys.argv) > 1 and sys.argv[1] == "-ri" and sys.argv[2] == "key":
    generate_key()
    sys.exit()

# === Interface ===

class RobloxCodeInjector(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Roblox Code Injector")
        self.geometry("900x650")
        self.configure(bg="#1e1e2f")

        self.comment_font = tkfont.Font(family="Consolas", size=11, slant="italic")

        self.notebook = None
        self.entry_user = None
        self.autocomplete_window = None

        self.show_login_screen()

    def show_login_screen(self):
        self.login_frame = tk.Frame(self, bg="#1e1e2f")
        self.login_frame.pack(expand=True)

        tk.Label(self.login_frame, text="Enter your Key", fg="white", bg="#1e1e2f", font=("Segoe UI", 14)).pack(pady=20)

        self.entry_key = tk.Entry(self.login_frame, font=("Segoe UI", 12), width=30)
        self.entry_key.pack(pady=10)

        tk.Button(self.login_frame, text="Login", command=self.validate_key, bg="#007acc", fg="white", font=("Segoe UI", 11)).pack(pady=10)

    def validate_key(self):
        user_key = self.entry_key.get().strip()
        valid_key = read_key_file()

        if user_key == valid_key:
            delete_key_file()
            self.login_frame.destroy()
            self.create_widgets()
        else:
            messagebox.showerror("Invalid Key", "The key you entered is invalid.")

    def create_widgets(self):
        top_frame = tk.Frame(self, bg="#2d2d44", padx=10, pady=10)
        top_frame.pack(fill=tk.X)

        tk.Label(top_frame, text="Username:", font=("Segoe UI", 12), fg="white", bg="#2d2d44").pack(side=tk.LEFT)
        self.entry_user = tk.Entry(top_frame, font=("Segoe UI", 12), width=25)
        self.entry_user.pack(side=tk.LEFT, padx=(5, 20))

        tk.Button(top_frame, text="New Script", command=self.new_script, bg="#007acc", fg="white").pack(side=tk.LEFT, padx=5)
        tk.Button(top_frame, text="Open Script", command=self.open_script, bg="#007acc", fg="white").pack(side=tk.LEFT, padx=5)
        tk.Button(top_frame, text="Save Script", command=self.save_script, bg="#007acc", fg="white").pack(side=tk.LEFT, padx=5)
        tk.Button(top_frame, text="Inject Code", command=self.send_code, bg="#007acc", fg="white").pack(side=tk.LEFT, padx=5)

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)

        style = ttk.Style()
        style.theme_use('default')
        style.configure('TNotebook.Tab', background="#444466", foreground='white', padding=[10, 5])
        style.map('TNotebook.Tab', background=[('selected', '#007acc')], foreground=[('selected', 'white')])

        self.new_script()

    def new_script(self):
        frame = tk.Frame(self.notebook, bg="#1e1e2f")
        editor = tk.Text(frame, font=("Consolas", 11), bg="#1e1e2f", fg="#d4d4d4", insertbackground="white", undo=True)
        editor.pack(expand=True, fill=tk.BOTH)
        editor.bind('<KeyRelease>', self.on_key_release)
        editor.bind('<Control-space>', self.show_autocomplete)

        editor.tag_configure("keyword", foreground="#569CD6")
        editor.tag_configure("string", foreground="#D69D85")
        editor.tag_configure("comment", foreground="#6A9955", font=self.comment_font)

        self.notebook.add(frame, text="New Script")
        self.notebook.select(frame)

    def open_script(self):
        path = filedialog.askopenfilename(filetypes=[("Lua Files", "*.lua"), ("All Files", "*.*")])
        if path:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            frame = tk.Frame(self.notebook, bg="#1e1e2f")
            editor = tk.Text(frame, font=("Consolas", 11), bg="#1e1e2f", fg="#d4d4d4", insertbackground="white", undo=True)
            editor.pack(expand=True, fill=tk.BOTH)
            editor.insert("1.0", content)
            editor.bind('<KeyRelease>', self.on_key_release)
            editor.bind('<Control-space>', self.show_autocomplete)

            editor.tag_configure("keyword", foreground="#569CD6")
            editor.tag_configure("string", foreground="#D69D85")
            editor.tag_configure("comment", foreground="#6A9955", font=self.comment_font)

            self.notebook.add(frame, text=path.split("/")[-1])
            self.notebook.select(frame)
            self.highlight_syntax(editor)

    def save_script(self):
        current = self.notebook.select()
        if not current:
            messagebox.showwarning("Warning", "No script open to save.")
            return
        frame = self.nametowidget(current)
        editor = frame.winfo_children()[0]
        code = editor.get("1.0", tk.END).strip()
        if not code:
            messagebox.showwarning("Warning", "Script is empty.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".lua",
                                            filetypes=[("Lua files", "*.lua"), ("All files", "*.*")])
        if path:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(code)
            messagebox.showinfo("Success", f"Script saved to {path}")
            filename = path.split("/")[-1]
            self.notebook.tab(current, text=filename)

    def send_code(self):
        user = self.entry_user.get().strip()
        if not user:
            messagebox.showerror("Error", "Please enter your username.")
            return

        current = self.notebook.select()
        if not current:
            messagebox.showerror("Error", "No script open to inject.")
            return

        frame = self.nametowidget(current)
        editor = frame.winfo_children()[0]
        code = editor.get("1.0", tk.END).strip()
        if not code:
            messagebox.showerror("Error", "Script is empty.")
            return

        url = 'http://localhost:3000/send-command'
        data = {'user': user, 'command': code}

        try:
            response = requests.post(url, json=data)
            if response.status_code == 200:
                messagebox.showinfo("Success", "Code injected successfully!")
            else:
                messagebox.showerror("Failed", "Failed to inject code.")
        except Exception as e:
            messagebox.showerror("Error", f"Error sending code: {e}")

    def on_key_release(self, event):
        self.highlight_syntax(event.widget)

    def highlight_syntax(self, editor):
        code = editor.get("1.0", tk.END)
        editor.tag_remove("keyword", "1.0", tk.END)
        editor.tag_remove("string", "1.0", tk.END)
        editor.tag_remove("comment", "1.0", tk.END)

        for match in re.finditer(r'--.*', code):
            start = f"1.0+{match.start()}c"
            end = f"1.0+{match.end()}c"
            editor.tag_add("comment", start, end)

        for match in re.finditer(r'(\".*?\"|\'.*?\')', code):
            start = f"1.0+{match.start()}c"
            end = f"1.0+{match.end()}c"
            editor.tag_add("string", start, end)

        for keyword in LUA_KEYWORDS:
            for match in re.finditer(r'\b' + re.escape(keyword) + r'\b', code):
                start = f"1.0+{match.start()}c"
                end = f"1.0+{match.end()}c"
                editor.tag_add("keyword", start, end)

    def show_autocomplete(self, event):
        editor = event.widget
        cursor_index = editor.index(tk.INSERT)
        line_start = editor.index(f"{cursor_index} linestart")
        text_before_cursor = editor.get(line_start, cursor_index)

        match = re.search(r"(\w+)$", text_before_cursor)
        if not match:
            self.close_autocomplete()
            return
        prefix = match.group(1).lower()

        suggestions = [kw for kw in LUA_KEYWORDS if kw.startswith(prefix)]
        if not suggestions:
            self.close_autocomplete()
            return

        if self.autocomplete_window is None or not self.autocomplete_window.winfo_exists():
            self.autocomplete_window = tk.Toplevel(self)
            self.autocomplete_window.wm_overrideredirect(True)
            self.autocomplete_window.configure(bg="#2d2d44")

            self.listbox = tk.Listbox(self.autocomplete_window, bg="#1e1e2f", fg="white", highlightthickness=0,
                                      selectbackground="#007acc", activestyle="none", font=("Consolas", 11))
            self.listbox.pack()

            self.listbox.bind("<<ListboxSelect>>", self.insert_autocomplete)
            self.listbox.bind("<Escape>", lambda e: self.close_autocomplete())
            self.listbox.bind("<Return>", self.insert_autocomplete)
            self.listbox.bind("<Double-Button-1>", self.insert_autocomplete)
        else:
            self.listbox.delete(0, tk.END)

        for s in suggestions:
            self.listbox.insert(tk.END, s)

        bbox = editor.bbox(tk.INSERT)
        if bbox:
            x, y, width, height = bbox
            x_root = editor.winfo_rootx() + x
            y_root = editor.winfo_rooty() + y + height
            self.autocomplete_window.geometry(f"+{x_root}+{y_root}")

        self.listbox.focus_set()

    def insert_autocomplete(self, event):
        if not self.listbox.curselection():
            return
        selection = self.listbox.get(self.listbox.curselection())

        editor = self.notebook.nametowidget(self.notebook.select()).winfo_children()[0]
        cursor_index = editor.index(tk.INSERT)
        line_start = editor.index(f"{cursor_index} linestart")
        text_before_cursor = editor.get(line_start, cursor_index)

        new_text_before = re.sub(r"(\w+)$", "", text_before_cursor)
        line_end = editor.index(f"{cursor_index} lineend")
        text_after_cursor = editor.get(cursor_index, line_end)

        editor.delete(line_start, line_end)
        editor.insert(line_start, new_text_before + selection + text_after_cursor)
        editor.mark_set(tk.INSERT, f"{line_start}+{len(new_text_before + selection)}c")

        self.close_autocomplete()

    def close_autocomplete(self):
        if self.autocomplete_window and self.autocomplete_window.winfo_exists():
            self.autocomplete_window.destroy()
        self.autocomplete_window = None


if __name__ == "__main__":
    app = RobloxCodeInjector()
    app.mainloop()